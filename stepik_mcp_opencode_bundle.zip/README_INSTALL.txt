STEPik MCP для OpenCode — установка обновления
============================================

Что умеет версия:
- читать весь урок и все step-sources;
- корректно читать code-задачи (условие, шаблоны, открытые/авторские тесты);
- получать комментарии к шагу и ко всему уроку;
- получать статистику урока: просмотры, среднее время, завершение (если поля отдаёт Stepik GET API);
- получать статистику задания: попытки/решения, успешность, число решивших, оценки/реакции при наличии в API;
- получать обезличенную выборку неверных решений;
- получать отзывы по всему курсу;
- собирать пакет lesson_bundle для AI-редактора.

Сервер остаётся READ-ONLY: в Stepik отправляются только GET-запросы.

1. Закройте OpenCode Desktop.

2. Откройте PowerShell:
   cd C:\Users\admin\stepik-mcp

3. Сделайте резервные копии старых файлов:
   Copy-Item .\stepik_bridge.py .\stepik_bridge_backup.py
   Copy-Item .\stepik_mcp.py .\stepik_mcp_backup.py

4. Скопируйте новые файлы stepik_bridge.py и stepik_mcp.py в:
   C:\Users\admin\stepik-mcp\
   согласившись на замену старых.

5. Проверка синтаксиса:
   .\.venv\Scripts\python.exe -m py_compile .\stepik_bridge.py .\stepik_mcp.py

6. Если в текущем PowerShell уже заданы STEPIK_CLIENT_ID/STEPIK_CLIENT_SECRET, проверьте связь:
   .\.venv\Scripts\python.exe -c "import stepik_mcp; print(stepik_mcp.stepik_whoami())"

   Если переменные не заданы в этом окне, повторно задайте их или просто тестируйте через OpenCode,
   если они уже прописаны в environment вашего opencode.json.

7. Запустите OpenCode Desktop снова. Конфиг OpenCode менять не требуется: имя сервера и пути те же.

Новые MCP-инструменты:
- stepik_step_comments(step_id, limit=100)
- stepik_lesson_comments(lesson_id, limit_per_step=50)
- stepik_lesson_stats(lesson_id, course_id=None)
- stepik_step_stats(step_id, max_submissions=2000)
- stepik_wrong_submissions(step_id, limit=10, scan_limit=1000)
- stepik_course_reviews(course_id, limit=100)
- stepik_lesson_bundle(lesson_id, ..., course_id=None)

Старые инструменты сохранены:
- stepik_whoami
- stepik_my_courses
- stepik_course_outline
- stepik_lesson
- stepik_step
- stepik_resolve

Примеры запросов в OpenCode:
1) "Прочитай урок 2498212 через Stepik MCP и покажи все шаги."
2) "Покажи все комментарии к уроку 2498212."
3) "Покажи статистику урока 2498212 в контексте курса <COURSE_ID>."
4) "Для code-задачи step <STEP_ID> покажи статистику и 15 неверных решений, затем сгруппируй типичные ошибки."
5) "Покажи отзывы по курсу <COURSE_ID> и сгруппируй повторяющиеся замечания."
6) "Получи lesson_bundle для урока 2498212 и проведи редакторскую проверку."

Примечание по статистике:
Stepik менял набор полей и часть аналитики зависит от прав/типа курса. Код сначала использует стандартные поля
(correct_ratio, passed_by, viewed_by, time_to_complete), а затем ищет доступные статистические поля и
read-only endpoints. Если конкретная метрика не вернётся, инструмент явно это напишет; тогда достаточно
показать вывод одного вызова, чтобы подстроить адаптер под фактический ответ вашего курса.
