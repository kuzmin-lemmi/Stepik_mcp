#!/usr/bin/env python3
"""
stepik_mcp.py — локальный read-only MCP-сервер для AI Course Workspace + Stepik.

Кладётся рядом с stepik_bridge.py и переиспользует его клиент и рендер.
По умолчанию транспорт stdio (OpenCode / Claude Desktop); --http сохраняется для удалённых клиентов.

Только чтение: ни один инструмент не делает пишущих запросов к Stepik.
"""

import os

from mcp.server.mcpserver import MCPServer

import stepik_bridge as sb

mcp = MCPServer(
    name="stepik",
    instructions=(
        "Read-only доступ к авторскому контенту и аналитике Stepik. "
        "Для структуры курса используй stepik_course_outline; для полного урока — stepik_lesson. "
        "Комментарии, статистика, неверные решения и отзывы запрашивай отдельными инструментами. "
        "Для редакторского анализа всего урока можно использовать stepik_lesson_bundle."
    ),
)


def _guard():
    """Вместо стектрейса возвращаем человеку понятную причину."""
    missing = [
        name for name in ("STEPIK_CLIENT_ID", "STEPIK_CLIENT_SECRET")
        if not os.environ.get(name)
    ]
    if missing:
        return "Не заданы переменные окружения: " + ", ".join(missing)
    return None


def _run(func, *args, **kwargs):
    problem = _guard()
    if problem:
        return problem
    try:
        return func(*args, **kwargs)
    except sb.StepikError as exc:
        return f"Ошибка Stepik: {exc}"
    except Exception as exc:
        return f"Ошибка MCP ({type(exc).__name__}): {exc}"


@mcp.tool(description="Проверить связь с Stepik и показать, под каким аккаунтом работает токен.")
def stepik_whoami() -> str:
    def work():
        payload = sb.CLIENT.get("stepics/1")
        user = (payload.get("users") or [{}])[0]
        return (
            f"Аккаунт: {user.get('full_name')} (id {user.get('id')})\n"
            f"Авторизация работает."
        )
    return _run(work)


@mcp.tool(description="Список курсов, где указанный аккаунт значится преподавателем. По умолчанию — текущий аккаунт.")
def stepik_my_courses(user_id: int | None = None) -> str:
    def work():
        uid = user_id
        if uid is None:
            payload = sb.CLIENT.get("stepics/1")
            uid = (payload.get("users") or [{}])[0].get("id")
        courses = sb.CLIENT.collect("courses", teacher=uid)
        if not courses:
            return f"У пользователя {uid} нет курсов с правами преподавателя."
        lines = [f"Курсы аккаунта {uid}:", ""]
        for course in courses:
            lines.append(f"- **{course.get('title')}** — `course/{course.get('id')}`")
        return "\n".join(lines)
    return _run(work)


@mcp.tool(description="Структура курса: секции, уроки и id каждого урока. Отсюда берутся id для stepik_lesson.")
def stepik_course_outline(course_id: int) -> str:
    return _run(sb.render_course, sb.CLIENT, course_id)


@mcp.tool(description="Полный текст урока со всеми шагами в markdown. answers=False скрывает правильные ответы.")
def stepik_lesson(lesson_id: int, answers: bool = True) -> str:
    return _run(sb.render_lesson, sb.CLIENT, lesson_id, False, answers)


@mcp.tool(description="Один шаг по его внутреннему id (не по номеру в уроке).")
def stepik_step(step_id: int, answers: bool = True) -> str:
    def work():
        sources = sb.CLIENT.by_ids("step-sources", [step_id], key="step-sources")
        if not sources:
            return f"Шаг {step_id} не найден или недоступен."
        return sb.render_step(sources[0], raw=False, answers=answers)
    return _run(work)


@mcp.tool(description="Принимает ссылку, скопированную из адресной строки Stepik: на курс, урок или конкретный шаг.")
def stepik_resolve(url: str, answers: bool = True) -> str:
    return _run(sb.resolve_url, sb.CLIENT, url, False, answers)


@mcp.tool(description="Комментарии к конкретному шагу Stepik с именами авторов. Только чтение.")
def stepik_step_comments(step_id: int, limit: int = 100) -> str:
    return _run(sb.render_step_comments, sb.CLIENT, step_id, limit)


@mcp.tool(description="Все комментарии по шагам одного урока Stepik, сгруппированные по номеру шага.")
def stepik_lesson_comments(lesson_id: int, limit_per_step: int = 50) -> str:
    return _run(sb.render_lesson_comments, sb.CLIENT, lesson_id, limit_per_step)


@mcp.tool(description="Просмотры, среднее время прохождения и число полностью прошедших урок.")
def stepik_lesson_stats(lesson_id: int, course_id: int | None = None) -> str:
    return _run(sb.render_lesson_stats, sb.CLIENT, lesson_id, course_id)


@mcp.tool(description="Статистика задания/шага: попытки, успешность, число решивших, оценки/реакции если API их возвращает.")
def stepik_step_stats(step_id: int, max_submissions: int = 2000) -> str:
    max_submissions = max(20, min(max_submissions, 10000))
    return _run(sb.render_step_stats, sb.CLIENT, step_id, max_submissions)


@mcp.tool(description="Обезличенная выборка неверных решений учащихся для анализа типичных ошибок. Имена/email/user_id не выводятся.")
def stepik_wrong_submissions(step_id: int, limit: int = 10, scan_limit: int = 1000) -> str:
    limit = max(1, min(limit, 50))
    scan_limit = max(limit, min(scan_limit, 10000))
    return _run(sb.render_wrong_submissions, sb.CLIENT, step_id, limit, scan_limit)


@mcp.tool(description="Отзывы учащихся по всему курсу Stepik; при наличии API также показывает сводку оценок.")
def stepik_course_reviews(course_id: int, limit: int = 100) -> str:
    limit = max(1, min(limit, 500))
    return _run(sb.render_course_reviews, sb.CLIENT, course_id, limit)


@mcp.tool(description="Пакет для AI-редактора: текст урока + программные задачи + комментарии + статистика + выборка неверных code-решений.")
def stepik_lesson_bundle(
    lesson_id: int,
    answers: bool = True,
    comments: bool = True,
    stats: bool = True,
    wrong_sample: int = 3,
    max_submissions: int = 1000,
    course_id: int | None = None,
) -> str:
    wrong_sample = max(0, min(wrong_sample, 20))
    max_submissions = max(20, min(max_submissions, 5000))
    return _run(
        sb.render_lesson_bundle,
        sb.CLIENT,
        lesson_id,
        answers,
        comments,
        stats,
        wrong_sample,
        max_submissions,
        course_id,
    )


# --------------------------------------------------------------------------
# Режимы запуска
# --------------------------------------------------------------------------

def _http_app():
    """Streamable HTTP + проверка Bearer-токена.

    Нужен для клиентов, которые не умеют запускать локальный процесс
    (ChatGPT и прочие) и ходят только по HTTPS.
    """
    import secrets

    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.responses import JSONResponse

    from mcp.server.transport_security import TransportSecuritySettings

    bearer = os.environ.get("MCP_BEARER_TOKEN", "")
    if len(bearer) < 24:
        raise SystemExit(
            "Задай MCP_BEARER_TOKEN длиной от 24 символов — сервер будет "
            "доступен из интернета, без него его найдут за часы."
        )

    class RequireBearer(BaseHTTPMiddleware):
        async def dispatch(self, request, call_next):
            header = request.headers.get("authorization", "")
            supplied = header[7:] if header.lower().startswith("bearer ") else ""
            if not secrets.compare_digest(supplied, bearer):
                return JSONResponse({"error": "unauthorized"}, status_code=401)
            return await call_next(request)

    app = mcp.streamable_http_app(
        stateless_http=True,
        # За туннелем Host приходит чужой, и защита от rebinding режет запрос.
        # Вместо неё дверь стережёт Bearer-токен выше.
        transport_security=TransportSecuritySettings(
            enable_dns_rebinding_protection=False
        ),
    )
    app.add_middleware(RequireBearer)
    return app


def _main():
    import sys

    if "--http" in sys.argv:
        import uvicorn

        port = int(os.environ.get("PORT", "8000"))
        uvicorn.run(_http_app(), host="127.0.0.1", port=port, log_level="info")
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    _main()
